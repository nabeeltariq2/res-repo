import os
from sqlalchemy import *








DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://nabeeltariq2:nabeeltariq2@nabeeltariq2.cpliemudyxqt.us-east-1.rds.amazonaws.com/nabeeltariq6?charset=utf8')


# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:sesame@localhost/movietweet?charset=utf8')



# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:sesame@localhost/movietweet_ratings?charset=utf8')



# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:sesame@localhost/movielensupgrade?charset=utf8')





# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://nabeeltariq3:nabeeltariq3@nabeeltariq3.cpliemudyxqt.us-east-1.rds.amazonaws.com/nabeeltariq3?charset=utf8')




# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://nabeeltariq2:nabeeltariq2@nabeeltariq2.cpliemudyxqt.us-east-1.rds.amazonaws.com/nabeeltariq2?charset=utf8')










# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://nabeeltariq2:nabeeltariq2@aa1taiyw3rzbwis.cpliemudyxqt.us-east-1.rds.amazonaws.com/aa1taiyw3rzbwis?charset=utf8')



# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://flask:nabeeltariq2@flasktest.cpliemudyxqt.us-east-1.rds.amazonaws.com/flaskdb?charset=utf8')


# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:sesame@localhost/movielens_meta?charset=utf8')

# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:sesame@localhost/amazonmusicalins2?charset=utf8')




# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://flask:nabeeltariq2@aa1bus1tdvnpq5m.cpliemudyxqt.us-east-1.rds.amazonaws.com/ebdb?charset=utf8')

#new database
# DB_URI = os.environ.get('DATABASE_URL', 'mysql+pymysql://nabeeltariq2:nabeeltariq2@aa14nod91ksnt0i.cpliemudyxqt.us-east-1.rds.amazonaws.com/ebdb?charset=utf8')
